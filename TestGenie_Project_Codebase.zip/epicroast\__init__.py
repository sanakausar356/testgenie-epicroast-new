"""
Epic Roast - AI-Powered Jira Ticket Roaster
"""

__version__ = "1.0.0"
__author__ = "Epic Roast Team"
__description__ = "A CLI tool that roasts Jira tickets using AI with humor and insight" 