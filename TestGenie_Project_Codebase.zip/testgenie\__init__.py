"""
TestGenie - AI-Powered Test Scenario Generator
"""

__version__ = "1.0.0"
__author__ = "TestGenie Team"
__description__ = "A command-line tool that generates test scenarios from acceptance criteria using Azure OpenAI" 