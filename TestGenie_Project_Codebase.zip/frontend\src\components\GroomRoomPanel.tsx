import { useState, useEffect, useRef } from 'react'
import ReactMarkdown from 'react-markdown'
import { Zap, Download, Copy, Share2, CheckCircle, AlertCircle, Search, Sparkles } from 'lucide-react'
import { generateGroom } from '../services/api'
import ReportTabs from './groom/ReportTabs'

interface GroomRoomPanelProps {
  sharedTicketNumber: string
  setSharedTicketNumber: (ticket: string) => void
  setIsLoading: (loading: boolean) => void
}

export const GroomRoomPanel: React.FC<GroomRoomPanelProps> = ({
  sharedTicketNumber,
  setSharedTicketNumber,
  setIsLoading
}) => {
  const [ticketNumber, setTicketNumber] = useState(sharedTicketNumber)
  const [ticketContent, setTicketContent] = useState('')
  const [level, setLevel] = useState('actionable')
  const [figmaLink, setFigmaLink] = useState('')
  const [results, setResults] = useState('')
  const [responseData, setResponseData] = useState<any>(null)
  const [error, setError] = useState('')
  const [showSuccess, setShowSuccess] = useState(false)
  const [validationError, setValidationError] = useState('')
  
  const ticketInputRef = useRef<HTMLInputElement>(null)

  // Auto-focus first input on mount
  useEffect(() => {
    if (ticketInputRef.current) {
      ticketInputRef.current.focus()
    }
  }, [])

  // Update ticket number when shared ticket changes
  useEffect(() => {
    if (sharedTicketNumber && !ticketNumber) {
      setTicketNumber(sharedTicketNumber)
    }
  }, [sharedTicketNumber, ticketNumber])

  const validateInputs = () => {
    if (!ticketNumber && !ticketContent.trim()) {
      setValidationError('Please provide either a ticket number or ticket content')
      return false
    }
    setValidationError('')
    return true
  }

  const handleGenerate = async () => {
    if (!validateInputs()) return

    setIsLoading(true)
    setError('')
    setValidationError('')
    
    try {
      console.log('Calling generateGroom with:', { ticket_number: ticketNumber, ticket_content: ticketContent, level })
      
      const response = await generateGroom({
        ticket_number: ticketNumber,
        ticket_content: ticketContent,
        level,
        figma_link: figmaLink || undefined
      })
      
      console.log('Response received:', response)
      console.log('Response success:', response.success)
      console.log('Response data:', response.data)
      console.log('Groom content length:', response.data?.groom?.length || 0)
      console.log('Groom content preview:', response.data?.groom?.substring(0, 200) || 'No content')
      
      if (response.success) {
        console.log('Response data:', response.data)
        
        // Handle new enhanced response format
        if (response.data.markdown && response.data.data) {
          console.log('Using enhanced response format')
          setResults(response.data.markdown)
          setResponseData(response.data.data)
        } else if (response.data.groom) {
          console.log('Using legacy response format')
          setResults(response.data.groom)
          setResponseData(null)
        } else {
          console.log('No valid response format found')
          setResults('No analysis content available')
          setResponseData(null)
        }
        
        if (ticketNumber) {
          setSharedTicketNumber(ticketNumber)
        }
        setShowSuccess(true)
        setTimeout(() => setShowSuccess(false), 3000)
      } else {
        console.log('Error in response:', response.error)
        let errorMessage = response.error || 'Failed to generate groom analysis'
        if (response.suggestion) {
          errorMessage += `\n\n💡 Suggestion: ${response.suggestion}`
        }
        setError(errorMessage)
      }
    } catch (err) {
      console.error('Exception in handleGenerate:', err)
      setError('Unable to reach GroomRoom service. Please check connection or try "Paste Ticket Content" instead.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(results)
      // Show success feedback
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const handleExport = () => {
    const blob = new Blob([results], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `groom-analysis-${ticketNumber || 'manual'}.md`
    a.click()
    URL.revokeObjectURL(url)
  }

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'insight': return '🔍'
      case 'actionable': return '⚡'
      case 'summary': return '📋'
      default: return '⚡'
    }
  }

  const formatResults = (rawResults: string) => {
    return (
      <div className="prose prose-lg max-w-none">
        <ReactMarkdown
          components={{
            h1: ({ children }) => (
              <h1 className="text-2xl font-bold text-secondary-700 mb-4 flex items-center">
                {children}
              </h1>
            ),
            h2: ({ children }) => (
              <h2 className="text-xl font-semibold text-secondary-600 mb-3 flex items-center">
                {children}
              </h2>
            ),
            p: ({ children }) => (
              <p className="text-gray-700 leading-relaxed mb-3">
                {children}
              </p>
            ),
            ul: ({ children }) => (
              <ul className="space-y-2 mb-4">
                {children}
              </ul>
            ),
            li: ({ children }) => (
              <li className="flex items-start space-x-2">
                <span className="text-secondary-500 mt-1">•</span>
                <span className="text-gray-700">{children}</span>
              </li>
            ),
            strong: ({ children }) => (
              <strong className="font-bold text-secondary-700">
                {children}
              </strong>
            ),
            em: ({ children }) => (
              <em className="italic text-gray-600">
                {children}
              </em>
            )
          }}
        >
          {rawResults}
        </ReactMarkdown>
        

      </div>
    )
  }

  return (
    <div className="card">
      <div className="flex items-center space-x-2 mb-6">
        <span className="text-2xl">🧹</span>
        <h2 className="text-xl font-semibold text-gray-900">Groom Room</h2>
        <span className="text-sm text-gray-500">Groom Analysis</span>
      </div>

      {/* Input Section */}
      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Jira Ticket Number
          </label>
          <input
            ref={ticketInputRef}
            type="text"
            value={ticketNumber}
            onChange={(e) => {
              setTicketNumber(e.target.value.toUpperCase())
              setValidationError('')
            }}
            placeholder="e.g., ODCD-33741"
            className={`beach-input w-full ${validationError && !ticketNumber && !ticketContent.trim() ? 'border-red-300 focus:border-red-500' : ''}`}
          />
          <p className="text-xs text-gray-500 mt-1">
            Enter a Jira ticket number to automatically fetch ticket content
          </p>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-300" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">OR</span>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Paste Ticket Content
          </label>
          <textarea
            value={ticketContent}
            onChange={(e) => {
              setTicketContent(e.target.value)
              setValidationError('')
            }}
            placeholder="Paste the ticket content to analyze... e.g., 'As a user, I want to be able to click a button'"
            rows={4}
            className={`beach-input w-full resize-none ${validationError && !ticketNumber && !ticketContent.trim() ? 'border-red-300 focus:border-red-500' : ''}`}
          />
          <p className="text-xs text-gray-500 mt-1">
            Paste the ticket description, acceptance criteria, or any content to analyze
          </p>
        </div>

        {/* Groom Level Options */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Groom Level {getLevelIcon(level)}
          </label>
          <select
            value={level}
            onChange={(e) => setLevel(e.target.value)}
            className="beach-input w-full"
          >
            <option value="insight">🔍 Insight (Balanced Groom)</option>
            <option value="actionable">⚡ Actionable (QA + DoR Coaching)</option>
            <option value="summary">📋 Summary (Snapshot)</option>
          </select>
          <p className="text-xs text-gray-500 mt-1">
            {level === 'insight' && 'Balanced analysis — highlights clarity, ACs, QA scenarios.'}
            {level === 'actionable' && 'Full prescriptive refinement guidance, includes rewrites.'}
            {level === 'summary' && 'Concise overview for leads and dashboards.'}
          </p>
        </div>

        {/* Figma Link (Optional) */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            🎨 Figma Link (Optional)
          </label>
          <input
            type="url"
            value={figmaLink}
            onChange={(e) => setFigmaLink(e.target.value)}
            placeholder="https://figma.com/design/..."
            className="beach-input w-full"
          />
          <p className="text-xs text-gray-500 mt-1">
            Add a Figma design link for DesignSync analysis and design validation
          </p>
        </div>

        {/* Validation Error */}
        {validationError && (
          <div className="flex items-center space-x-2 p-3 bg-red-50 border border-red-200 rounded-lg">
            <AlertCircle className="h-4 w-4 text-red-500" />
            <p className="text-red-700 text-sm">{validationError}</p>
          </div>
        )}

        <button
          onClick={handleGenerate}
          className="beach-button w-full flex items-center justify-center space-x-2"
        >
          <Search className="h-4 w-4" />
          <span>Generate Groom Analysis</span>
        </button>
      </div>

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {/* Success Animation */}
      {showSuccess && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg animate-pulse">
          <div className="flex items-center space-x-2">
            <CheckCircle className="h-4 w-4 text-green-500" />
            <p className="text-green-700 text-sm">Groom analysis generated successfully!</p>
          </div>
        </div>
      )}

      {/* Results Section */}
      {results && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">Groom Analysis</h3>
            <div className="flex space-x-2">
              <button
                onClick={handleCopy}
                className="btn-outline flex items-center space-x-1 text-sm"
                title="Copy to clipboard"
              >
                <Copy className="h-4 w-4" />
                <span>Copy</span>
              </button>
              <button
                onClick={handleExport}
                className="btn-outline flex items-center space-x-1 text-sm"
                title="Download as markdown"
              >
                <Download className="h-4 w-4" />
                <span>Export</span>
              </button>
              <button 
                className="btn-outline flex items-center space-x-1 text-sm"
                title="Share to Teams"
              >
                <Share2 className="h-4 w-4" />
                <span>Teams</span>
              </button>
            </div>
          </div>
          
          {/* Use new ReportTabs component for enhanced response, fallback to old format */}
          {responseData ? (
            <ReportTabs markdown={results} data={responseData} />
          ) : (
            <div className="bg-white border border-gray-200 rounded-lg p-6 max-h-[600px] overflow-y-auto shadow-sm">
              <div className="prose prose-sm max-w-none">
                {formatResults(results)}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
} 