#!/usr/bin/env python3
"""
Epic Roast - AI-Powered Jira Ticket Roaster
"""

from epicroast.cli import main

if __name__ == '__main__':
    main() 