"""
Debug the API response formatting to understand why it's still showing 0%
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from groomroom.core import GroomRoom
from app import _format_actionable_from_structured

def debug_api_response():
    """Debug the API response formatting"""
    
    print("🔍 Debugging API Response Formatting")
    print("=" * 50)
    
    # Sample content
    sample_content = """
    As a customer, I want to apply discount codes at checkout so that I can save money on my purchases.
    
    Acceptance Criteria:
    - User can enter discount code in checkout form
    - System validates the code against active promotions
    - Discount is applied to the total order amount
    - User sees confirmation of applied discount
    
    Test Scenarios:
    - Valid code applies correct discount
    - Invalid code shows error message
    - Expired code shows appropriate message
    """
    
    try:
        # Initialize GroomRoom
        print("1. Initializing GroomRoom...")
        groomroom = GroomRoom()
        print("✅ GroomRoom initialized")
        
        # Run analysis
        print("\n2. Running analysis...")
        result = groomroom.analyze_ticket(sample_content, mode="actionable")
        
        print("\n3. Raw result structure:")
        print(f"Keys: {list(result.keys())}")
        print(f"Mode: {result.get('mode')}")
        print(f"Display format: {result.get('display_format')}")
        print(f"Readiness score: {result.get('readiness_score')}")
        print(f"Ticket key: {result.get('ticket_key')}")
        
        # Check sections
        sections = result.get('sections', {})
        print(f"\n4. Sections:")
        for section_name, section_data in sections.items():
            print(f"  {section_name}: {type(section_data)} with keys: {list(section_data.keys())}")
        
        # Test the formatting function
        print("\n5. Testing formatting function...")
        formatted_output = _format_actionable_from_structured(result)
        print("Formatted output:")
        print(formatted_output)
        
        # Check what the API is actually getting
        print("\n6. API analysis structure:")
        analysis = {
            'groom': formatted_output,
            'level': 'actionable',
            'ticket_number': '',
            'sprint_readiness': result.get('SprintReadiness', result.get('readiness_score', 0)),
            'type': result.get('Type', result.get('ticket_key', 'Unknown')),
            'issues_found': result.get('DefinitionOfReady', {}).get('MissingFields', []),
            'suggestions': result.get('Recommendations', [])
        }
        
        print(f"Sprint readiness: {analysis['sprint_readiness']}")
        print(f"Type: {analysis['type']}")
        print(f"Issues found: {analysis['issues_found']}")
        print(f"Suggestions: {analysis['suggestions']}")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    debug_api_response()