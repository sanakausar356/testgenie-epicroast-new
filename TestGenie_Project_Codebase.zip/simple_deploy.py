#!/usr/bin/env python3
"""
Simple TestGenie Deployment Script
Works on Windows and provides detailed output
"""

import os
import subprocess
import sys
from pathlib import Path

def run_command(command, cwd=None):
    """Run a command and return the result"""
    print(f"Running: {command}")
    if cwd:
        print(f"Working directory: {cwd}")
    
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True
        )
        print(f"✅ Success: {result.stdout}")
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: {e.stderr}")
        return None

def check_tools():
    """Check if required tools are available"""
    print("🔍 Checking tools...")
    
    tools = {
        "Node.js": "node --version",
        "npm": "npm --version", 
        "Python": "python --version"
    }
    
    all_good = True
    for tool_name, command in tools.items():
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ {tool_name}: {result.stdout.strip()}")
            else:
                print(f"❌ {tool_name}: Not found")
                all_good = False
        except Exception as e:
            print(f"❌ {tool_name}: Error - {e}")
            all_good = False
    
    return all_good

def install_cli_tools():
    """Install Vercel and Railway CLI"""
    print("📦 Installing CLI tools...")
    
    tools = [
        ("Vercel CLI", "npm install -g vercel"),
        ("Railway CLI", "npm install -g @railway/cli")
    ]
    
    for tool_name, command in tools:
        print(f"Installing {tool_name}...")
        if run_command(command):
            print(f"✅ {tool_name} installed successfully")
        else:
            print(f"❌ Failed to install {tool_name}")
            return False
    
    return True

def deploy_backend():
    """Deploy backend to Railway"""
    print("🚀 Deploying backend to Railway...")
    
    backend_dir = Path("backend")
    if not backend_dir.exists():
        print("❌ Backend directory not found")
        return False
    
    # Change to backend directory
    original_dir = os.getcwd()
    os.chdir(backend_dir)
    
    try:
        # Check if railway.toml exists
        if not Path("railway.toml").exists():
            print("Creating railway.toml...")
            railway_config = """[build]
builder = "nixpacks"

[deploy]
startCommand = "gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --timeout 120"
healthcheckPath = "/health"
healthcheckTimeout = 300
restartPolicyType = "on_failure"
"""
            with open("railway.toml", "w") as f:
                f.write(railway_config)
            print("✅ Created railway.toml")
        
        # Deploy to Railway
        print("Deploying to Railway...")
        if run_command("railway up --detach"):
            print("✅ Backend deployed successfully to Railway")
            return True
        else:
            print("❌ Failed to deploy backend to Railway")
            return False
    
    finally:
        # Return to original directory
        os.chdir(original_dir)

def deploy_frontend():
    """Deploy frontend to Vercel"""
    print("🚀 Deploying frontend to Vercel...")
    
    frontend_dir = Path("frontend")
    if not frontend_dir.exists():
        print("❌ Frontend directory not found")
        return False
    
    # Change to frontend directory
    original_dir = os.getcwd()
    os.chdir(frontend_dir)
    
    try:
        # Install dependencies
        print("Installing frontend dependencies...")
        if not run_command("npm install"):
            print("❌ Failed to install frontend dependencies")
            return False
        
        # Build the project
        print("Building frontend...")
        if not run_command("npm run build"):
            print("❌ Failed to build frontend")
            return False
        
        # Deploy to Vercel
        print("Deploying to Vercel...")
        if run_command("vercel --prod --yes"):
            print("✅ Frontend deployed successfully to Vercel")
            return True
        else:
            print("❌ Failed to deploy frontend to Vercel")
            return False
    
    finally:
        # Return to original directory
        os.chdir(original_dir)

def main():
    """Main deployment function"""
    print("🚀 Starting TestGenie Deployment")
    print("=" * 50)
    
    # Check tools
    if not check_tools():
        print("❌ Required tools not found. Please install Node.js, npm, and Python")
        sys.exit(1)
    
    # Install CLI tools
    if not install_cli_tools():
        print("❌ Failed to install CLI tools")
        sys.exit(1)
    
    # Deploy backend first
    print("\n" + "=" * 50)
    if not deploy_backend():
        print("❌ Backend deployment failed")
        sys.exit(1)
    
    # Deploy frontend
    print("\n" + "=" * 50)
    if not deploy_frontend():
        print("❌ Frontend deployment failed")
        sys.exit(1)
    
    print("\n🎉 Deployment completed successfully!")
    print("\nNext steps:")
    print("1. ✅ Backend deployed on Railway")
    print("2. ✅ Frontend deployed on Vercel")
    print("3. 🔧 Update API URL in frontend/vercel.json with your Railway URL")
    print("4. 🔧 Set environment variables in Railway dashboard:")
    print("   - AZURE_OPENAI_ENDPOINT")
    print("   - AZURE_OPENAI_API_KEY")
    print("   - AZURE_OPENAI_DEPLOYMENT_NAME")
    print("   - JIRA_SERVER_URL")
    print("   - JIRA_EMAIL")
    print("   - JIRA_API_TOKEN")
    print("\nYour application should now be live!")

if __name__ == "__main__":
    main() 