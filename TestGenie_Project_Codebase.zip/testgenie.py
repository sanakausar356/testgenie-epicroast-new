#!/usr/bin/env python3
"""
TestGenie - A command-line tool for generating test scenarios from acceptance criteria
"""

from testgenie.cli import main

if __name__ == '__main__':
    main() 